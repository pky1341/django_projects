from typing_extensions import Self
from django.db import models

# Create your models here.
class Customer(models.Model):
    fname=models.CharField(max_length=30,null=True)
    lname=models.CharField(max_length=30)
    dob=models.DateField(null=True)
    gen=models.CharField(max_length=30)
    email=models.EmailField(max_length=60,primary_key=True)
    password=models.CharField(max_length=20,null=True)
    phone=models.CharField(max_length=10)
    addr=models.TextField(max_length=200)
    
    def is_exists(self):
        if Customer.objects.filter(email=self.email): # type: ignore
            return True
        else:
            return False
    
    def __str__(self):
        return "%s %s %s %s %s"%(self.fname,self.lname,self.email,self.password,self.addr)