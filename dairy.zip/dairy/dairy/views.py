from django.shortcuts import render

from dairy_app.models import Images

def index(request):
    photo=Images.objects.all()  # type: ignore
    return render(request,"index.html",{'photo':photo})
def product(request):
    return render(request,"product.html")
def about(request):
    return render(request,"about.html")
def contact(request):
    return render(request,"contact.html")
def check(request):
    return render(request,"check.html")