from django.shortcuts import render

from .models import Customer

# Create your views here.
def index(request):
    if request.method=='POST':
        err=None
        fname=request.POST.get('fname')
        lname=request.POST.get('lname')
        dob=request.POST.get('dob')
        gender=request.POST.get('a')
        email=request.POST.get('email')
        password=request.POST.get('passwd')
        contact=request.POST.get('contact')
        address=request.POST.get('addr')
        customer=Customer(fname=fname,lname=lname,dob=dob,gen=gender,email=email,password=password,phone=contact,addr=address)
        #validate
        values={
            'fname':fname,
            'lname':lname,
            'dob':dob,
            'gender':gender,
            'email':email,
            'password':password,
            'contact':contact,
            'address':address,
        }
        if not fname.isalpha():
            err="Incorrect First Name,please Enter..."
        if not lname.isalpha():
            err="Incorrect Last Name,please Enter..."
        if not len(contact)<10 or contact.isnumeric():
            err="Incorrect number,please Enter.."
        if customer.is_exists():#type:ignore
            err="email already existed..."
            
        data={}
        data['err']=err
        data['values']=values
        if err:
            return render(request,"index.html",data)
        customer.save()
        err="Ragistered successfully"
        return render(request,"main.html",{'err':err})
    else:
        return render(request,"index.html")
def login(request):
    return render(request,"login.html")
def main(request):
    return render(request,"main.html")